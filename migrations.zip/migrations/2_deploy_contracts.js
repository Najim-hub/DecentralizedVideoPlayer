const FairyTube = artifacts.require("FairyTube");

module.exports = function(deployer) {
  deployer.deploy(FairyTube);
};
